from setuptools import setup, find_packages


setup(
    name= "src", 
    version= "0.0.1",
    Description= "its an MLops Experimentation setup",
    author= "U_Vamsi_Krishna",
    packages= find_packages(),
)